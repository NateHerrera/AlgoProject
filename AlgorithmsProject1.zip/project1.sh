#!/bin/bash

python3 PyScript.py
